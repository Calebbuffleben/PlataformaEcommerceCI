GNU License

Projeto de Estudo Acadêmico que envolve
A linguagem de PHP 5.3 e o Framework CodeIgniter 1.7.2
e o controlador de Versão gitHub.

O projeto é um exercicio de como criar e manter uma 
loja virtual usando a linguagem php o framework 
codeigniter e ao mesmo tempo controlar a versão 
do projeto com o gitHub.

Neste projeto de Loja Vitual podemos cadastrar produtos,
adiconar descrição com imagem. Podemos, t adicionar
usuários respeitando uma determinada hierarquia.

Site do projeto: http://lojavirtualcodeigniter1.azurewebsites.net/

<p align="center">
  <img src="lojavirtual.png" width="350"/>
</p>
