<?php
  
  
  echo heading("Email encaminhado com sucesso!");
  echo "<p>Obrigado por ter entrado em contato conosco </p>";
  echo br(2);
  
  echo "<a href='javascript:history.go(-1)'>Voltar</a> | <a href='".base_url()."'>Home</a>";
  
?>